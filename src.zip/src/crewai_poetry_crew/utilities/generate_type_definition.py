from pydantic import BaseModel
from .models import PoetModel, ArchitectModel, EditorModel, CriticModel

# Returns: ["type", "title", "text", "version"]
def model_field_names(model_cls: type[BaseModel]) -> list[str]:
    return list(model_cls.model_fields.keys())

# Returns: Poem (type, title, text, version).
def generate_object_definition(model_cls: type[BaseModel]) -> str:
    fields = ", ".join(model_field_names(model_cls))
    return f"{model_cls.__name__.removesuffix("Model")} ({fields})"

# Returns: PoemMode = JSON with fields: type, title, text, version.
def generate_type_definition(model_cls: type[BaseModel]) -> str:
    fields = ", ".join(model_field_names(model_cls))
    return f"{model_cls.__name__} = JSON with fields: {fields}."
