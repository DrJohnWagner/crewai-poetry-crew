from crewai import LLM, Agent
from crewai_poetry_crew.utilities.globals import EXTRACT_ARCHITECT_NOTES_FROM_INPUT, EXTRACT_POEM_FROM_INPUT, GLOBAL_META_GUARDRAILS
from crewai_poetry_crew.utilities.generate_type_definition import generate_type_definition
from crewai_poetry_crew.utilities.models import ArchitectModel, PsychologistModel, PoetModel
from crewai_poetry_crew.utilities.save_to_file import save_to_file

GOAL = f"""
    Diagnose psychological dynamics and provide persona-aware leverage
    for revision without altering text.
"""

BACKSTORY = f"""
    {generate_type_definition(PoetModel)}
    {generate_type_definition(ArchitectModel)}
    {generate_type_definition(PsychologistModel)}
    {GLOBAL_META_GUARDRAILS}

    You are the Psychologist. You observe the poem as a clinical presentation.
    You identify conflicts, trauma loops, dissociation, and defenses.
    
    You do NOT rewrite. You provide the diagnostic fuel for others to revise.
"""

def PsychologistAgent(
    llm: LLM,
    name: str = "Psychologist",
    role: str = "System Psychologist",
    tools: list = [],
    memory: bool = False,
    verbose: bool = False,
    allow_delegation: bool = False,
    save_backstory: bool = False,
    ) -> Agent:
    if save_backstory:
        save_to_file(BACKSTORY, f"descriptions/{name}.txt")
    return Agent(
        llm=llm,
        name=name,
        role=role,
        tools=tools,
        memory=memory,
        goal=GOAL,
        backstory=BACKSTORY,
        verbose=verbose,
        allow_delegation=allow_delegation,
    )